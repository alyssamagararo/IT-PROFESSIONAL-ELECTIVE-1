package com.example.motivationalqouteapp.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface QuoteDao {

    @Query("SELECT * FROM quotes")
    List<Quote> getAllQuotes();

    @Insert
    void insert(Quote quote);
}
