package com.example.motivationalqouteapp.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "quotes")
public class Quote {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String text;

    public Quote(String text) {
        this.text = text;
    }
}
