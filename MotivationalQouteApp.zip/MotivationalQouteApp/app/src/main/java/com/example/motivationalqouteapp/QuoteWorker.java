package com.example.motivationalqouteapp;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.example.motivationalqouteapp.data.Quote;
import com.example.motivationalqouteapp.data.QuoteDatabase;

import java.util.List;
import java.util.Random;

public class QuoteWorker extends Worker {

    private static final String CHANNEL_ID = "daily_quote_channel";

    public QuoteWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {

        // Get database
        QuoteDatabase db = QuoteDatabase.getInstance(getApplicationContext());
        List<Quote> quotes = db.quoteDao().getAllQuotes();

        if (!quotes.isEmpty()) {
            // Pick a random quote
            Random random = new Random();
            Quote randomQuote = quotes.get(random.nextInt(quotes.size()));

            // Show notification
            showNotification(randomQuote.text);
        }

        return Result.success();
    }

    private void showNotification(String quote) {
        NotificationManager notificationManager =
                (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);

        // Create notification channel for Android O+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Daily Quote",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            notificationManager.createNotificationChannel(channel);
        }

        // Build notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_ID)
                .setContentTitle("Motivational Quote")
                .setContentText(quote)
                .setSmallIcon(R.drawable.ic_launcher_foreground) // you can replace with your app icon
                .setAutoCancel(true);

        // Show notification
        notificationManager.notify(new Random().nextInt(), builder.build());
    }
}
