package com.example.motivationalqouteapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private TextView txtQuote;
    private Button btnFavorite, btnFavoritesList;
    private ConstraintLayout mainLayout;

    private String[] quotes = {
            "Believe in yourself, %s!",
            "Stay positive, work hard, make it happen, %s.",
            "Your only limit is your mind, %s.",
            "Dream it. Wish it. Do it, %s.",
            "Don't stop until you're proud, %s.",
            "Push yourself, because no one else will, %s.",
            "Success doesn't come to you, you go to it, %s.",
            "Great things never come from comfort zones, %s.",
            "Dream bigger. Do bigger, %s.",
            "Little things make big days, %s.",
            "Don't wait for opportunity. Create it, %s.",
            "Sometimes later becomes never. Do it now, %s.",
            "The harder you work for something, the greater you'll feel when you achieve it, %s.",
            "Don't watch the clock; do what it does. Keep going, %s.",
            "Focus on goals, not obstacles, %s.",
            "Believe you can and you're halfway there, %s.",
            "It always seems impossible until it’s done, %s.",
            "Work hard in silence. Let success make the noise, %s.",
            "Small efforts repeated daily lead to success, %s.",
            "Quit talking and begin doing, %s.",
            "You don’t need to be great to start, but you need to start to be great, %s.",
            "Do something today your future self will thank you for, %s.",
            "Your vibe attracts your tribe, %s.",
            "Be productive, not busy, %s.",
            "Getting ahead starts with getting started, %s.",
            "Challenge your limits, %s.",
            "Doubt kills more dreams than failure ever will, %s.",
            "Stand up every time you fall, %s.",
            "Hustle quietly, let success be your noise, %s.",
            "Habit keeps you going, %s.",
            "The best view comes after the hardest climb, %s.",
            "Take the moment and make it perfect, %s.",
            "You are capable of amazing things, %s.",
            "Small progress is still progress, %s.",
            "Do what you can with what you have, %s.",
            "Stop wishing. Start doing, %s.",
            "Your future starts today, %s.",
            "Be stronger than your excuses, %s.",
            "Hard does not mean impossible, %s.",
            "Ordinary becomes extraordinary with effort, %s.",
            "Success is who you are, not what you have, %s.",
            "Follow your dreams, not your fears, %s.",
            "Start where you are, %s.",
            "Success is not for the lazy, %s.",
            "Your imagination is your limitation, %s.",
            "Pain today becomes strength tomorrow, %s.",
            "Work until your idols become your rivals, %s.",
            "Don't quit, champion %s.",
            "Great things take time, %s.",
            "Be the energy you want to attract, %s."
    };

    private ArrayList<String> favoriteQuotes = new ArrayList<>();
    private int currentIndex = 0;

    private GestureDetector gestureDetector;

    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "FavoriteQuotesPrefs";
    private static final String KEY_FAVORITES = "favorites";
    private static final String KEY_USERNAME = "username";

    private String userName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainLayout = findViewById(R.id.mainLayout);
        txtQuote = findViewById(R.id.txtQuote);
        btnFavorite = findViewById(R.id.btnFavorite);
        btnFavoritesList = findViewById(R.id.btnFavoritesList);

        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        loadFavorites();
        loadUserName();

        if (userName.isEmpty()) {
            askUserName();
        } else {
            txtQuote.setText(String.format(quotes[currentIndex], userName));
        }

        updateFavoriteButton();

        btnFavorite.setOnClickListener(v -> {
            String currentQuote = String.format(quotes[currentIndex], userName);
            if (favoriteQuotes.contains(currentQuote)) {
                favoriteQuotes.remove(currentQuote);
                Toast.makeText(this, "Removed from favorites", Toast.LENGTH_SHORT).show();
            } else {
                favoriteQuotes.add(currentQuote);
                Toast.makeText(this, "Added to favorites", Toast.LENGTH_SHORT).show();
            }
            saveFavorites();
            updateFavoriteButton();
        });

        btnFavoritesList.setOnClickListener(v -> {
            if (favoriteQuotes.isEmpty()) {
                Toast.makeText(this, "No favorite quotes yet!", Toast.LENGTH_SHORT).show();
            } else {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Favorite Quotes");
                StringBuilder message = new StringBuilder();
                for (String q : favoriteQuotes) {
                    message.append("• ").append(q).append("\n\n");
                }
                builder.setMessage(message.toString());
                builder.setPositiveButton("Close", null);
                builder.show();
            }
        });

        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            private static final int SWIPE_THRESHOLD = 150;
            private static final int SWIPE_VELOCITY_THRESHOLD = 150;

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                float diffY = e1.getY() - e2.getY();
                float diffX = e2.getX() - e1.getX();

                if (Math.abs(diffY) > Math.abs(diffX)) {
                    if (diffY > SWIPE_THRESHOLD && Math.abs(velocityY) > SWIPE_VELOCITY_THRESHOLD) {
                        showNextQuote();
                        return true;
                    }
                }
                return false;
            }

            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }
        });

        mainLayout.setOnTouchListener((v, event) -> gestureDetector.onTouchEvent(event));
    }

    private void showNextQuote() {
        currentIndex = (currentIndex + 1) % quotes.length;
        txtQuote.setText(String.format(quotes[currentIndex], userName));
        updateFavoriteButton();
    }

    private void updateFavoriteButton() {
        String currentQuote = String.format(quotes[currentIndex], userName);
        if (favoriteQuotes.contains(currentQuote)) {
            btnFavorite.setText("♥ Favorited");
        } else {
            btnFavorite.setText("♡ Favorite");
        }
    }

    private void saveFavorites() {
        Set<String> set = new HashSet<>(favoriteQuotes);
        sharedPreferences.edit().putStringSet(KEY_FAVORITES, set).apply();
    }

    private void loadFavorites() {
        Set<String> set = sharedPreferences.getStringSet(KEY_FAVORITES, new HashSet<>());
        favoriteQuotes = new ArrayList<>(set);
    }

    private void loadUserName() {
        userName = sharedPreferences.getString(KEY_USERNAME, "");
    }

    private void askUserName() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Welcome!");
        builder.setMessage("What is your name?");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        builder.setCancelable(false);

        builder.setPositiveButton("OK", (dialog, which) -> {
            userName = input.getText().toString().trim();

            if (userName.isEmpty()) userName = "Friend";

            sharedPreferences.edit().putString(KEY_USERNAME, userName).apply();

            txtQuote.setText(String.format(quotes[currentIndex], userName));
        });

        builder.show();
    }
}
